//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by financedemo.rc
//
#define IDD_FINANCEDEMO_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_TIMERANGE                   1000
#define IDC_CHARTSIZE                   1001
#define IDC_VOLUME                      1002
#define IDC_LOGSCALE                    1003
#define IDC_PABABOLICSAR                1004
#define IDC_PERCENTAGESCALE             1006
#define IDC_CHARTTYPE                   1007
#define IDC_BAND                        1008
#define IDC_AVGTYPE1                    1009
#define IDC_AVGTYPE2                    1010
#define IDC_MOVAVG1                     1011
#define IDC_MOVAVG2                     1012
#define IDC_INDICATOR1                  1013
#define IDC_INDICATOR2                  1014
#define IDC_INDICATOR3                  1015
#define IDC_INDICATOR4                  1016
#define IDC_CHARTVIEWER                 1017
#define IDC_TICKERSYMBOL                1020
#define IDC_COMPAREWITH                 1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
